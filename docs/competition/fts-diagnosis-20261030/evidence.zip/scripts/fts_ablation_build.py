"""Build isolated one-change variants; never edit the submission checkout."""
import hashlib
import json
import os
import pathlib
import subprocess
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
REPO = ROOT/'work/submission'
N = pathlib.Path('/var/tmp/seekdb-fts-finish-20261030')
E = ROOT/'outputs/seekdb-fts-diagnosis'
E.mkdir(exist_ok=True)
TOOLS = pathlib.Path('/var/tmp/codex-seekdb-native-12cd8fd/source/deps/3rd/usr/local/oceanbase/devtools')
DEVEL = pathlib.Path('/var/tmp/seekdb-ai-competition-20261028/work/devel')
ENV = dict(os.environ, PATH=str(TOOLS/'bin')+':'+os.environ['PATH'],
           LD_LIBRARY_PATH=f'{DEVEL}/lib:{DEVEL}/lib64:{TOOLS}/lib64',
           CARGO_HOME='/mnt/d/codex11/2026-10-28/new-chat/work/toolchain/cargo',
           RUSTUP_HOME='/mnt/d/codex11/2026-10-28/new-chat/work/toolchain/rustup',
           RUSTUP_TOOLCHAIN='1.98.1', CARGO_BUILD_JOBS='2')
BASE='965b5d35ec36218bffd2ece8442b2bf8038d4c9a'
FINAL='0668450b7a85a293cd41150d5771f9bfe034ce97'
CPP='src/storage/fts/ob_fts_stop_word.cpp'
HEADER='src/storage/fts/ob_fts_stop_word.h'
def git(ref, path):
    return subprocess.check_output(['git','-C',str(REPO),'show',ref+':'+path])
def groupby(data):
    start=data.index(b'int ObAddWord::groupby_word(')
    end=data.index(b'\n}',start)+2
    return data[start:end]
old,new=git(BASE,CPP),git(FINAL,CPP)
variants={
    'frequency': {CPP:old.replace(groupby(old),groupby(new)), HEADER:git(BASE,HEADER)},
    'stopword': {CPP:new.replace(groupby(new),groupby(old)), HEADER:git(FINAL,HEADER)},
    'candidate': {CPP:new,HEADER:git(FINAL,HEADER)},
}
records=[]
manifest={}
def run(label,cmd):
    start=time.monotonic()
    print('START',label,flush=True)
    with (E/(label+'.log')).open('w') as f:
        result=subprocess.run(list(map(str,cmd)),env=ENV,stdout=f,stderr=subprocess.STDOUT)
    records.append(dict(name=label,exit_code=result.returncode,seconds=time.monotonic()-start))
    (E/'build-state.json').write_text(json.dumps(records,indent=2))
    print('END',label,result.returncode,flush=True)
    if result.returncode:
        print((E/(label+'.log')).read_text(errors='replace')[-3000:],flush=True)
        raise SystemExit(result.returncode)
try:
    for label,files in variants.items():
        for path,content in files.items():
            dest=N/'source'/path
            if dest.read_bytes()!=content:dest.write_bytes(content)
        manifest[label]={'source':{p:hashlib.sha256(c).hexdigest() for p,c in files.items()}}
        (E/(label+'.cpp')).write_bytes(files[CPP])
        run('build-'+label,[TOOLS/'bin/cmake','--build',N/'build','--target','seekdb','oceanbase','-j','3'])
        binary=N/'bin'/('seekdb-'+label+'-diagnosis')
        run('strip-'+label,[TOOLS/'bin/llvm-objcopy','--strip-debug',N/'build/src/observer/seekdb',binary])
        manifest[label]['binary']=str(binary)
        manifest[label]['sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
        run('cpp-'+label,['python3',N/'source/unittest/storage/fts/run_fts_cpp.py',
                         '--build-dir',N/'build','--output',E/('cpp-'+label)])
        (E/'binary-manifest.json').write_text(json.dumps(manifest,indent=2))
finally:
    for path in [CPP,HEADER]:
        desired=git(FINAL,path)
        dest=N/'source'/path
        if dest.read_bytes()!=desired:dest.write_bytes(desired)
binary=N/'bin/seekdb-submitted'
manifest['submitted']={'binary':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'commit':BASE}
manifest['candidate']['commit']=FINAL
assert manifest['submitted']['sha256']=='8223c112ab56576470121b250fce34444bfb4fb4c24bbd57adf93da08c9f27e5'
(E/'binary-manifest.json').write_text(json.dumps(manifest,indent=2))
print('ALL VARIANTS BUILT AND CPP VERIFIED',flush=True)
