"""Preserve all three experiments and document the actually verified selection."""
import pathlib
source=pathlib.Path(__file__).with_name('fts_diagnosis_package.py').read_text(encoding='utf-8')
exec(compile(source,'fts_phase12_package.py','exec'))
phase=E/'ik-comparison';release=E/'release'
data=read(phase/'ablation-summary.json');selection=read(release/'selection.json')
assert data['completed']==18
assert selection['rebuilt_binary_sha256']==selection['measured_binary_sha256']
assert all(r['exit_code']==0 for r in read(release/'build-state.json'))
state=read(release/'measure-state.json')
assert len(state)==5 and all(r['exit_code']==0 for r in state)
assert '"different_cases": []' in (release/'sql-release.log').read_text(encoding='utf-8')
for p,sha in selection['sources'].items():
    content=(REPO/p).read_bytes() if (REPO/p).exists() else subprocess.check_output(['git','-C',str(REPO),'show','965b5d3:'+p])
    assert hashlib.sha256(content).hexdigest()==sha,p
choice=selection['choice']
names={'original':'首次 FTS 修改前','selected':'IK + BENG 优化','ik_only':'仅 IK 优化'}
chosen=data['summaries'][choice]
base=data['summaries']['original']
summary=[]
for version,s in data['summaries'].items():
    summary.append(f"| {names[version]} | {pct(s['categories']['build'])} | {pct(s['categories']['tokenize'])} | {pct(s['categories']['query'])} | {pct(s['composite'])} |")
metricrows=[]
for m,b in base['means'].items():
    if m=='select1_avg_ms':continue
    c=chosen['means'][m]
    metricrows.append(f'| {m} | {b:.6g} | {c:.6g} | {pct(1-c/b)} |')
earlier=(DOC/'REPORT.md').read_text(encoding='utf-8')
(DOC/'PHASES_1_2.md').write_bytes(('> 本文件保留前两阶段的完整记录；最新选择和第三阶段数据见 [最新报告](REPORT.md)。\n\n'+earlier).encode('utf-8'))
production_paths=subprocess.check_output(['git','-C',str(REPO),'diff','--name-only','02fb66c1d41e637a2f4aba7fe050e6028b6f23ef','--','src']).decode().splitlines()
keep='保留 IK 字符分类、仲裁、词典及生命周期修复，并保留 BENG 分配优化' if choice=='selected' else '保留 IK 字符分类、仲裁、词典及生命周期修复；BENG 五个生产文件恢复首次 FTS 修改前实现'
decision='仅 IK 版没有显示足够可靠的优势，因此没有继续撤出已有 BENG 改动' if choice=='selected' else '进一步收缩为仅 IK 版，撤出未显示可靠收益的 BENG 分配改动'
main=f'''# 全文索引调优：最终排查与提交说明

**最终选择：{names[choice]}。本机六轮相对首次 FTS 修改前版本的综合均值变化为 {pct(chosen['composite'])}；正式平台结果尚未取得，不能宣称已达到性能目标或满分。**

## 已落实的修改

1. 撤回 `0668450` 新增的单次词频更新和 ASCII 停用词索引。16 轮拆分对照中，仅词频、仅停用词、两项同时启用的综合均值分别为 −4.10%、−4.36%、−5.04%，没有可靠的整机收益证据。
2. {keep}。{decision}。最终相对首次 FTS 修改前版本涉及 {len(production_paths)} 个生产文件，不改动该分支已有 AI 功能。
3. 保留新增的词频、排序规则和停用词语义回归测试；修正测试输出和说明，避免将已撤回的实现继续描述为当前实现。
4. 用完整服务端完成三阶段共 **42 轮**新基准，并保留全部结果；之前八轮也保留在历史报告中。没有修改基准脚本、数据、SQL、计时逻辑、评分脚本、固定基线或工作流。

## 三阶段实验及决定

第一阶段为四版本 16 轮拆分对照；第二阶段为撤回两项新增优化后与首次 FTS 修改前版本的八轮比较。第二阶段综合均值为 −3.17%，分词退化较明显，因而增加第三阶段来验证 BENG 是否应撤出。前两阶段的全部数字见 [完整记录](PHASES_1_2.md)，没有用后续数据覆盖或删除不利结果。

第三阶段包括原始版、IK+BENG 版和仅 IK 版，预先固定全部六种排列，每种排列三轮，共 18 轮。每种版本在每个出场位置出现两次。每轮全新数据目录，统一启动后等待 20 秒，不穿插 SQL 回归。各版本六轮耗时均值的比较如下；三类内部各指标先平均，再对三类等权平均，负值不在单项层面截断。

| 版本 | 构建 | 分词 | 查询 | 综合 |
|---|---:|---:|---:|---:|
{chr(10).join(summary)}

最终选择版本在六个组内相对原始版的综合变化依次为：{', '.join(pct(x) for x in chosen['block_composites'])}。选择依据是这些完整实验及缩小未证实改动范围的考虑，不是统计显著性证明；同一批数据用于选择版本，不能将其当作独立验证得到的稳定收益。

## 最终版本九项指标

原始版为 `02fb66c1d41e637a2f4aba7fe050e6028b6f23ef`，其 FTS 文件与原官方比较点一致，保留已有 AI 功能。生产变体的确切源码及可执行文件 SHA-256 见 `evidence/ik-comparison/binary-manifest.json`，最终选择见 `evidence/release/selection.json`。

| 指标 | 原始版六轮均值 | 最终版六轮均值 | 耗时下降 |
|---|---:|---:|---:|
{chr(10).join(metricrows)}

这张表对比的是同机原始源码版本，不是平台固定基线。固定基线评分只作参考，全部原始评分输出均保留。正式成绩以平台实际输入为准。

## 最终验证

最终选择后重新构建 `seekdb`、`oceanbase`，生成的服务端二进制与被测变体 **SHA-256 完全一致**：`{selection['rebuilt_binary_sha256']}`。

最终重新通过七组 C++ 检查，包含 3,336,192 项字符分类及 121,140 项停用词语义对照；936 项完整 SQL 结果核对一致，包括词元/词频、文档长度、完整命中 ID、相关性、top-k、DML 与回滚；四项 mysqltest 全部通过，原预期结果未改。这不等于整个官方套件或平台 CI 已通过。本次专用测试服务均已停止。

三种拆分变体、原始版和最终变体的逐次验证日志均保留。测试过程从未使用查询命中数量代替完整正确性验证。

## 条件与限制

统一参数为 `ROWS=20000 BATCH=500 ROUNDS=3000 QUERY_ROUNDS=200 SAMPLES=3 WARMUP=30 SKIP_LOAD=0`。每轮新报告、重新导入和建索引；未删异常样本，未扣除 SELECT 1 耗时。

环境为 WSL2 / Ubuntu 20.04、Clang 17、RelWithDebInfo；服务端绑定 CPU 12,14，客户端 CPU 10；`cpu_count=2`、`memory_limit=2G`。另一个既有实例保留运行，未擅自停止。每秒采集资源状态，但不能完整观测 Windows 宿主机干扰；CPU 绑定不等于独占 CPU。

此前 −169.70% 的严重退化没有以同样幅度重现，这并不能证明旧结果无效或确定根因。仍有运行和采样波动；仅 IK 版也出现 BENG 慢样本，因此不能仅凭早期英文分词退化断定 BENG 改动有缺陷。

增量构建保留的版本字符串和基准 `git_head/git_dirty` 不足以标识实验变体；以源码清单和二进制 SHA-256 为准。所有变体都是完整服务端构建，没有用测试对象替代生产构建。

## 平台核对与下一步

已重新核对公开基线与提交仓库一致。题面所列 `.github/workflows/vldb.yml` 在公开分支查询返回 404；另一个 `seekdb.yml` 使用 OceanBase 专用 runner，不能作为个人仓库的比赛评分入口。没有自行改造或伪造官方评测流程。

此前平台给出的同一组耗时按公开文件复算与平台返回分数不一致，平台实际基线和评分版本仍未知。GitHub 上传不等于平台提测。本次尚未通过平台重新提交。需要在已登录的比赛平台对最终分支提测，核对实际拉取的提交 SHA，并取得九项计分指标和实际评分基线；具体问题和可发送文本见 [平台核对材料](PLATFORM_CHECK.md)。未代发消息给任何人。

完整证据在 `evidence.zip`，可浏览汇总及全部 42 轮原始基准、评分在 `evidence/`。本机诊断脚本快照也在压缩包内；标准功能复验方法见 `unittest/storage/fts/README.md`。
'''
(DOC/'REPORT.md').write_bytes(main.encode('utf-8'))
(E/'最终排查报告.md').write_bytes(main.encode('utf-8'))
for folder,relative in [(phase,pathlib.Path('ik-comparison')),(release,pathlib.Path('release'))]:
    dest=DOC/'evidence'/relative;dest.mkdir(parents=True,exist_ok=True)
    for name in ['ablation-summary.json','protocol.json','binary-manifest.json','build-state.json','measure-state.json','benchmark-integrity.json','selection.json']:
        if (folder/name).exists():shutil.copyfile(folder/name,dest/name)
    for pattern in ['b*-p*-*.txt','b*-p*-*-score.log','sql-*.log','mysqltest-*.log']:
        for p in folder.glob(pattern):shutil.copyfile(p,dest/p.name)
fixed=read(E/'fixed-reference-scores.json')
fixed['ik_comparison']={r['label']:read(phase/(r['label']+'-score.log'))['score'] for r in data['runs']}
(E/'fixed-reference-scores.json').write_text(json.dumps(fixed,indent=2),encoding='utf-8')
shutil.copyfile(E/'fixed-reference-scores.json',DOC/'evidence/fixed-reference-scores.json')
files=[p for p in E.rglob('*') if p.is_file() and p.suffix in allowed and p.name not in ['publication.json','evidence-manifest.json']]
with zipfile.ZipFile(E/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):z.write(p,p.relative_to(E).as_posix())
    for p in sorted((ROOT/'work').glob('fts_*.py')):z.write(p,'scripts/'+p.name)
shutil.copyfile(E/'evidence.zip',DOC/'evidence.zip')
manifest=dict(archive_sha256=hashlib.sha256((E/'evidence.zip').read_bytes()).hexdigest(),
              archive_size=(E/'evidence.zip').stat().st_size,total_new_benchmark_rounds=42,
              selected_variant=choice,release_sha256=selection['rebuilt_binary_sha256'],platform_resubmitted=False)
(E/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
shutil.copyfile(E/'evidence-manifest.json',DOC/'evidence-manifest.json')
for p in DOC.rglob('*'):
    if p.is_file() and p.suffix in ['.md','.json','.txt','.log']:p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
print('FINAL PACKAGE',choice,'comparison',chosen['composite'],'bytes',manifest['archive_size'])
