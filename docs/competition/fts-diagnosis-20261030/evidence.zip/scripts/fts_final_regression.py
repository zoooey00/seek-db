"""Run final functional checks after all timing measurements have finished."""
import pathlib
import sys
source=pathlib.Path(__file__).with_name('fts_ablation_measure.py').read_text()
sys.argv=[sys.argv[0],'--final']
prefix=source[:source.index('for item in PLAN:')]
exec(compile(prefix,'fts_final_lifecycle.py','exec'))
assert all(any(r['name']==item['label']+'-score' and r['exit_code']==0 for r in records) for item in PLAN)
last=next(x for x in reversed(PLAN) if x['version']=='original')
p=start('original','sql-original',runtime(last['label']),False)
try:
    run('sql-original',['python3',SOURCE/'unittest/storage/fts/check_fts_sql.py','--mysql',CLIENT,
                       '--port','2901','--benchmark-results','--compare',
                       ROOT/'outputs/seekdb-fts-final/validation/fresh-reference.json','--output',E/'sql-original'])
finally:stop(p)
last=next(x for x in reversed(PLAN) if x['version']=='selected')
p=start('selected','mysqltest-final',runtime(last['label']),False)
try:
    suite=SOURCE/'tools/deploy/mysql_test/test_suite/fts_index'
    for name in ['tokenize_function','parser_properties','parser_hot_path','simple_query']:
        test=suite/('t/'+name+'.test');expected=suite/('r/mysql/'+name+'.result')
        wrapper=E/(name+'.wrapper.test')
        wrapper.write_text('let $OBMYSQL_MS0=127.0.0.1;\nlet $OBMYSQL_PORT=2901;\nlet $OBMYSQL_PWD=;\nsource '+str(test)+';\n')
        input_test=wrapper if '$OBMYSQL' in test.read_text() else test
        before=expected.read_bytes()
        run('mysqltest-'+name,[CLIENT.parent/'mysqltest','--no-defaults','--protocol=tcp','--host=127.0.0.1',
            '--port=2901','--user=root','--database=oceanbase','--default-character-set=utf8mb4',
            '--test-file='+str(input_test),'--result-file='+str(expected),'--logdir='+str(E),'--tmpdir='+str(N)],cwd=suite)
        assert expected.read_bytes()==before
finally:stop(p)
print('FINAL FUNCTIONAL CHECKS COMPLETE; TEST SERVERS STOPPED',flush=True)
