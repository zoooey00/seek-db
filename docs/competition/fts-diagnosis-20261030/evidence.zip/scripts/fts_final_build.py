"""Build the pre-FTS submission parent, then the selected production sources."""
import hashlib
import json
import pathlib
import shutil
import subprocess

# Import only constants and command recorder, not the ablation build loop.
source=pathlib.Path(__file__).with_name('fts_ablation_build.py').read_text()
prefix=source[:source.index('old,new=')]
exec(compile(prefix,'fts_build_constants.py','exec'))
import time
E=ROOT/'outputs/seekdb-fts-diagnosis/final-comparison'
E.mkdir(exist_ok=True)
records=[]
def run(label,cmd):
    start=time.monotonic();print('START',label,flush=True)
    with (E/(label+'.log')).open('w') as f:
        p=subprocess.run(list(map(str,cmd)),env=ENV,stdout=f,stderr=subprocess.STDOUT)
    records.append(dict(name=label,exit_code=p.returncode,seconds=time.monotonic()-start))
    (E/'build-state.json').write_text(json.dumps(records,indent=2))
    print('END',label,p.returncode,flush=True)
    if p.returncode:
        print((E/(label+'.log')).read_text(errors='replace')[-3000:],flush=True)
        raise SystemExit(p.returncode)
PARENT='02fb66c1d41e637a2f4aba7fe050e6028b6f23ef'
paths=subprocess.check_output(['git','-C',str(REPO),'diff','--name-only',PARENT,BASE,'--','src','deps']).decode().splitlines()
assert len(paths)==12,paths
paths += [CPP,HEADER]
chosen={p:(REPO/p).read_bytes() if (REPO/p).exists() else git(BASE,p) for p in paths}
for p in paths:assert chosen[p]==git(BASE,p),p
manifest={}
try:
    for label,files in [('original',{p:git(PARENT,p) for p in paths}),('selected',chosen)]:
        for p,b in files.items():
            dest=N/'source'/p
            if dest.read_bytes()!=b:dest.write_bytes(b)
        for p in ['unittest/storage/fts/test_fts_hot_path.cpp','unittest/storage/fts/README.md']:
            shutil.copyfile(REPO/p,N/'source'/p)
        run('build-'+label,[TOOLS/'bin/cmake','--build',N/'build','--target','seekdb','oceanbase','-j','3'])
        binary=N/'bin'/('seekdb-'+label+'-final')
        run('strip-'+label,[TOOLS/'bin/llvm-objcopy','--strip-debug',N/'build/src/observer/seekdb',binary])
        manifest[label]=dict(binary=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                             production_commit=PARENT if label=='original' else BASE,
                             sources={p:hashlib.sha256(b).hexdigest() for p,b in files.items()})
        (E/'binary-manifest.json').write_text(json.dumps(manifest,indent=2))
    run('cpp-selected',['python3',N/'source/unittest/storage/fts/run_fts_cpp.py',
                         '--build-dir',N/'build','--output',E/'cpp-selected'])
finally:
    for p,b in chosen.items():
        dest=N/'source'/p
        if dest.read_bytes()!=b:dest.write_bytes(b)
print('ORIGINAL AND SELECTED BUILT; FINAL CPP CHECKS PASS',flush=True)
