"""Balanced four-variant experiment using untouched benchmark and fresh instances."""
import hashlib
import argparse
import json
import os
import pathlib
import signal
import socket
import subprocess
import threading
import time

ROOT=pathlib.Path(__file__).resolve().parents[1]
N=pathlib.Path('/var/tmp/seekdb-fts-finish-20261030')
E=ROOT/'outputs/seekdb-fts-diagnosis'
parser=argparse.ArgumentParser()
parser.add_argument('--final',action='store_true')
parser.add_argument('--ik',action='store_true')
args=parser.parse_args()
assert not (args.final and args.ik)
if args.final:E=E/'final-comparison'
if args.ik:E=E/'ik-comparison'
SOURCE=N/'source'
TOOLS=pathlib.Path('/var/tmp/codex-seekdb-native-12cd8fd/source/deps/3rd/usr/local/oceanbase/devtools')
DEVEL=pathlib.Path('/var/tmp/seekdb-ai-competition-20261028/work/devel')
CLIENT=pathlib.Path('/mnt/d/codex11/2026-10-28/new-chat/work/mysqltest/u01/obclient/bin/obclient')
ENV=dict(os.environ,LD_LIBRARY_PATH=f'{DEVEL}/lib:{DEVEL}/lib64:{TOOLS}/lib64')
MANIFEST=json.loads((E/'binary-manifest.json').read_text())
VERSIONS=['submitted','frequency','stopword','candidate']
# Williams design: each version occupies every position, every ordered pair
# of distinct versions occurs once within blocks. All 16 runs are retained.
ORDERS=[[0,1,3,2],[1,2,0,3],[2,3,1,0],[3,0,2,1]]
if args.final:
    VERSIONS=['original','selected']
    ORDERS=[[0,1],[1,0],[1,0],[0,1]]
if args.ik:
    VERSIONS=['original','selected','ik_only']
    ORDERS=[[0,1,2],[2,1,0],[1,0,2],[2,0,1],[1,2,0],[0,2,1]]
PLAN=[dict(block=b+1,position=p+1,version=VERSIONS[v],label=f'b{b+1}-p{p+1}-{VERSIONS[v]}')
      for b,order in enumerate(ORDERS) for p,v in enumerate(order)]
config=dict(rows=20000,batch=500,rounds=3000,query_rounds=200,samples=3,warmup=30,skip_load=0)
protocol=dict(plan=PLAN,parameters=config,server_cpus='12,14',client_cpu='10',
              cpu_count=2,memory_limit='2G',fresh_empty_data_directory_every_run=True,
              startup_settle_seconds=20,regression_between_runs=False,
              discard_outliers=False,subtract_select1=False,other_services_untouched=True)
protocol_path=E/'protocol.json'
if protocol_path.exists():assert json.loads(protocol_path.read_text())==protocol
else:protocol_path.write_text(json.dumps(protocol,indent=2))
for v,m in MANIFEST.items():
    assert hashlib.sha256(pathlib.Path(m['binary']).read_bytes()).hexdigest()==m['sha256'],v
old_integrity=json.loads((ROOT/'outputs/seekdb-fts-final/validation/benchmark-integrity.json').read_text())
for p,expected in old_integrity.items():
    if isinstance(expected,str):assert hashlib.sha256((SOURCE/p).read_bytes()).hexdigest()==expected,p
(E/'benchmark-integrity.json').write_text(json.dumps(old_integrity,indent=2))
records=json.loads((E/'measure-state.json').read_text()) if (E/'measure-state.json').exists() else []
def save(): (E/'measure-state.json').write_text(json.dumps(records,indent=2))
def run(label,cmd,env=ENV,cwd=None):
    print('START',label,flush=True)
    start=time.monotonic()
    with (E/(label+'.log')).open('w') as log:
        p=subprocess.run(list(map(str,cmd)),env=env,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,timeout=600)
    records.append(dict(name=label,exit_code=p.returncode,seconds=time.monotonic()-start))
    save()
    print('END',label,p.returncode,round(time.monotonic()-start,2),flush=True)
    if p.returncode:
        print((E/(label+'.log')).read_text(errors='replace')[-2500:],flush=True)
        raise RuntimeError(label+' failed')
def snapshot(pid):
    d=dict(time=time.time(),load=pathlib.Path('/proc/loadavg').read_text().strip())
    d['cpu']=[s for s in pathlib.Path('/proc/stat').read_text().splitlines()
              if s.split()[0] in ['cpu','cpu10','cpu12','cpu14']]
    d['memory']=[s for s in pathlib.Path('/proc/meminfo').read_text().splitlines()
                 if s.split(':')[0] in ['MemAvailable','SwapFree','Dirty','Writeback']]
    d['pressure']={k:(pathlib.Path('/proc/pressure')/k).read_text() for k in ['cpu','memory','io']}
    d['seekdb']={}
    for p in pathlib.Path('/proc').iterdir():
        if not p.name.isdecimal():continue
        try:
            if (p/'comm').read_text().strip()!='seekdb':continue
            d['seekdb'][p.name]={'stat':(p/'stat').read_text(),
                               'status':[s for s in (p/'status').read_text().splitlines()
                                         if s.split(':')[0] in ['VmRSS','VmSwap','Threads','Cpus_allowed_list']],
                               'io':(p/'io').read_text()}
        except (FileNotFoundError,PermissionError,ProcessLookupError):pass
    return d
def monitor(pid,label,event):
    with (E/(label+'-telemetry.jsonl')).open('w') as out:
        while not event.is_set():
            out.write(json.dumps(snapshot(pid))+'\n');out.flush();event.wait(1)
def start(version,label,runtime,fresh):
    for port in [2901,2902]:
        for _ in range(30):
            with socket.socket() as sock:busy=sock.connect_ex(('127.0.0.1',port))==0
            if not busy:break
            time.sleep(.1)
        else:raise RuntimeError('Port in use: '+str(port))
    if fresh:runtime.mkdir(parents=True,exist_ok=False)
    cmd=['taskset','-c','12,14',MANIFEST[version]['binary'],'--nodaemon','--base-dir',str(runtime),'-P','2901',
         '--parameter','cpu_count=2','--parameter','memory_limit=2G',
         '--parameter','datafile_size=1G','--parameter','datafile_maxsize=4G',
         '--parameter','log_disk_size=2G','--parameter','max_syslog_file_count=3',
         '--parameter','enable_rpc_service=true','--parameter','rpc_port=2902','--log-level','WARN']
    with (E/(label+'-server.log')).open('w') as log:
        p=subprocess.Popen(cmd,cwd=runtime,env=ENV,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    print('SERVER',label,p.pid,flush=True)
    (E/'active-instance.json').write_text(json.dumps(dict(pid=p.pid,runtime=str(runtime),command=cmd)))
    try:
        for _ in range(120):
            if p.poll() is not None:raise RuntimeError('Server exited')
            r=subprocess.run([str(CLIENT),'--no-defaults','-h127.0.0.1','-P2901','-uroot','-N','-s','-e','SELECT 1'],
                             env=ENV,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=10)
            if r.returncode==0:break
            time.sleep(1)
        else:raise RuntimeError('Startup timeout')
        return p
    except BaseException:
        stop(p)
        raise
def stop(p):
    if p.poll() is None:
        p.send_signal(signal.SIGTERM)
        try:p.wait(timeout=60)
        except subprocess.TimeoutExpired:
            p.kill();p.wait();raise RuntimeError('Dedicated child required forced stop')
def runtime(label):return N/('diagnosis-ik-runtimes' if args.ik else 'diagnosis-final-runtimes' if args.final else 'diagnosis-runtimes')/label

for item in PLAN:
    label=item['label'];v=item['version']
    if any(r['name']==label+'-score' and r['exit_code']==0 for r in records):
        print('KEEP completed',label,flush=True);continue
    report=E/(label+'.txt')
    if report.exists():raise RuntimeError('Refuse to overwrite report '+label)
    p=start(v,label,runtime(label),True)
    event=threading.Event();thread=threading.Thread(target=monitor,args=(p.pid,label,event))
    thread.start()
    try:
        time.sleep(20)
        begin=time.time()
        env=dict(ENV,MYSQL=f'taskset -c 10 {CLIENT} --no-defaults -h127.0.0.1 -P2901 -uroot -N -s -A --default-character-set=utf8mb4',
                 MYSQL_VERBOSE=f'taskset -c 10 {CLIENT} --no-defaults -h127.0.0.1 -P2901 -uroot -A --default-character-set=utf8mb4',
                 LABEL=label,OUTPUT=str(report),**{k.upper():str(x) for k,x in config.items()})
        run(label,['taskset','-c','10','bash',SOURCE/'tools/benchmark/fts_large_bench.sh'],env,SOURCE)
        finish=time.time()
        (E/(label+'-runtime.json')).write_text(json.dumps(dict(**item,pid=p.pid,benchmark_start=begin,
             benchmark_end=finish,binary_sha256=MANIFEST[v]['sha256'],runtime=str(runtime(label))),indent=2))
        run(label+'-score',['python3',SOURCE/'tools/benchmark/fts_large_bench_score.py',report,'--json'])
    finally:
        event.set();thread.join();stop(p)

# Correctness happens only after every performance run is finished.
for v in VERSIONS[1:]:
    label='sql-'+v
    if any(r['name']==label and r['exit_code']==0 for r in records):continue
    last=next(x for x in reversed(PLAN) if x['version']==v)
    p=start(v,label,runtime(last['label']),False)
    try:
        run(label,['python3',SOURCE/'unittest/storage/fts/check_fts_sql.py','--mysql',CLIENT,
                   '--port','2901','--benchmark-results','--compare',
                   ROOT/'outputs/seekdb-fts-final/validation/fresh-reference.json','--output',E/label])
    finally:stop(p)
print(len(PLAN),'BALANCED ROUNDS AND',len(VERSIONS)-1,'FULL SQL COMPARISONS COMPLETE',flush=True)
