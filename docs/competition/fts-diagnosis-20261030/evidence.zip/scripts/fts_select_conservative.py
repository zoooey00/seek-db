"""Remove unsupported incremental changes while retaining regression coverage."""
import pathlib
import subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]
REPO=ROOT/'work/submission'
for path in ['src/storage/fts/ob_fts_stop_word.cpp','src/storage/fts/ob_fts_stop_word.h']:
    content=subprocess.check_output(['git','-C',str(REPO),'show','965b5d35ec36218bffd2ece8442b2bf8038d4c9a:'+path])
    (REPO/path).write_bytes(content)
test=REPO/'unittest/storage/fts/test_fts_hot_path.cpp'
text=test.read_text(encoding='utf-8')
text=text.replace('PASS one-pass word frequency updates:', 'PASS word frequency semantics:')
text=text.replace('for (const bool fast : {false, true, true, false})',
                  'for (const bool current : {false, true, true, false})')
text=text.replace('const int ret = fast ?', 'const int ret = current ?')
text=text.replace('fast ? "indexed" : "legacy"', 'current ? "current" : "legacy"')
text=text.replace('// Isolate the changed hash-map operation from SQL, network and JSON costs.',
                  '// Compare two hash-map APIs independently of the production implementation.')
test.write_bytes(text.encode('utf-8'))
readme=REPO/'unittest/storage/fts/README.md'
text=readme.read_text(encoding='utf-8')
text=text.replace('and frequency checks. `--benchmark-stopwords` measures thread CPU time in ABBA\norder for ASCII hits, ASCII misses and fallback inputs separately; it checks\nthat hit counts agree. `--benchmark-word-map` measures the frequency update.\nThese operation-level measurements do not measure complete SQL query latency.',
'''and frequency checks. `--benchmark-stopwords` compares the current production
checker with the independent legacy oracle using thread CPU time in ABBA order
for ASCII hits, ASCII misses and fallback inputs; it checks that hit counts agree.
`--benchmark-word-map` compares two hash-map APIs as an isolated experiment,
independently of which API production uses. Neither experiment measures complete
SQL query latency. The one-pass frequency update and ASCII stopword index were
withdrawn after the balanced full-server experiment did not establish a benefit;
their semantic regression coverage remains.''')
readme.write_bytes(text.encode('utf-8'))
print('Restored the two production files to 965b5d3; retained semantic tests.')
