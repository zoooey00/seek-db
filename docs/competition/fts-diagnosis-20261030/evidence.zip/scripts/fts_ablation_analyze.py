"""Summarize every preplanned run without trimming or changing scoring inputs."""
import argparse
import json
import pathlib
import statistics

ROOT=pathlib.Path(__file__).resolve().parents[1]
E=ROOT/'outputs/seekdb-fts-diagnosis'
CATEGORIES={
 'build':['build_ik_all_sec','build_ik_content_sec','build_beng_en_sec'],
 'tokenize':['tokenize_ik_avg_ms','tokenize_beng_avg_ms'],
 'query':['query_cn_avg_ms','query_beng_avg_ms','query_mixed_avg_ms','query_limit_avg_ms'],
}
def parse(path):
    out={}
    for line in path.read_text(encoding='utf-8').splitlines():
        key,sep,value=line.partition(':')
        if sep:
            try:out[key.strip()]=float(value.strip())
            except ValueError:pass
    return out
def improvement(base,current):
    categories={k:statistics.mean(1-current[m]/base[m] for m in metrics) for k,metrics in CATEGORIES.items()}
    return dict(categories=categories,composite=statistics.mean(categories.values()))
def telemetry(label):
    meta=json.loads((E/(label+'-runtime.json')).read_text())
    data=[json.loads(x) for x in (E/(label+'-telemetry.jsonl')).read_text().splitlines()]
    data=[x for x in data if meta['benchmark_start']<=x['time']<=meta['benchmark_end']]
    if len(data)<2:raise RuntimeError('Missing telemetry: '+label)
    first,last=data[0],data[-1]
    elapsed=last['time']-first['time']
    cpus={}
    for a,b in zip(first['cpu'],last['cpu']):
        name=a.split()[0];delta=[int(y)-int(x) for x,y in zip(a.split()[1:9],b.split()[1:9])]
        cpus[name]={'busy_fraction':1-(delta[3]+delta[4])/sum(delta),'iowait_fraction':delta[4]/sum(delta)}
    memory=[int(next(s for s in row['memory'] if s.startswith('MemAvailable:')).split()[1]) for row in data]
    pressures={}
    for key in first['pressure']:
        def total(s):return int(s.splitlines()[0].split('total=')[1])
        pressures[key]=(total(last['pressure'][key])-total(first['pressure'][key]))/1e6/elapsed
    return dict(samples=len(data),observed_seconds=elapsed,cpu=cpus,
                min_mem_available_kib=min(memory),pressure_some_fraction=pressures)

def main():
    global E
    p=argparse.ArgumentParser();p.add_argument('--partial',action='store_true');p.add_argument('--final',action='store_true');p.add_argument('--ik',action='store_true');args=p.parse_args()
    assert not (args.final and args.ik)
    if args.final:E=E/'final-comparison'
    if args.ik:E=E/'ik-comparison'
    protocol=json.loads((E/'protocol.json').read_text())
    plan=protocol['plan'];runs=[]
    for item in plan:
        label=item['label'];path=E/(label+'.txt')
        if not (E/(label+'-runtime.json')).exists():continue
        values=parse(path)
        assert all(values[k]==v for k,v in protocol['parameters'].items()),label
        for k,v in dict(query_cn_hits=8001,query_beng_hits=11000,query_mixed_hits=7332,query_limit_hits=20).items():
            assert values[k]==v,(label,k)
        runs.append(dict(**item,metrics=values,telemetry=telemetry(label)))
    if not args.partial:assert len(runs)==len(plan)
    versions=list(dict.fromkeys(x['version'] for x in plan))
    baseline=versions[0]
    allmetrics=sum(CATEGORIES.values(),[])+['select1_avg_ms']
    summaries={}
    for v in versions:
        matched=[x for x in runs if x['version']==v]
        if not matched:continue
        means={m:statistics.mean(x['metrics'][m] for x in matched) for m in allmetrics}
        summaries[v]=dict(count=len(matched),means=means,
                          ranges={m:[min(x['metrics'][m] for x in matched),max(x['metrics'][m] for x in matched)] for m in allmetrics})
    if baseline in summaries:
        for v,s in summaries.items():
            s.update(improvement(summaries[baseline]['means'],s['means']))
            s['block_composites']=[]
            for block in sorted({x['block'] for x in plan}):
                before=next((r for r in runs if r['version']==baseline and r['block']==block),None)
                after=next((r for r in runs if r['version']==v and r['block']==block),None)
                if before and after:s['block_composites'].append(improvement(before['metrics'],after['metrics'])['composite'])
    output=dict(completed=len(runs),preplanned=len(plan),summaries=summaries,runs=runs)
    if not args.partial:(E/'ablation-summary.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
    print('Completed',len(runs),'/',len(plan))
    for v,s in summaries.items():
        print(v,s['count'],'composite',round(s.get('composite',0)*100,3),
              'categories',{k:round(x*100,3) for k,x in s.get('categories',{}).items()},
              'blocks',[round(x*100,3) for x in s.get('block_composites',[])],
              'select1',round(s['means']['select1_avg_ms'],4))
if __name__=='__main__':main()
