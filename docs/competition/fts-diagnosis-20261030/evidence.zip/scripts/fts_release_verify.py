"""Publish only a measured variant into the checkout and verify that exact binary."""
import argparse
import pathlib
import sys
parser=argparse.ArgumentParser();parser.add_argument('choice',choices=['selected','ik_only'])
choice=parser.parse_args().choice
source=pathlib.Path(__file__).with_name('fts_final_build.py').read_text()
exec(compile(source[:source.index('PARENT=')],'release_build_common.py','exec'))
DIAG=ROOT/'outputs/seekdb-fts-diagnosis'
phase=DIAG/'ik-comparison'
plan=json.loads((phase/'protocol.json').read_text())['plan']
state=json.loads((phase/'measure-state.json').read_text())
assert len(plan)==18 and all(any(r['name']==x['label']+'-score' and r['exit_code']==0 for r in state) for x in plan)
variant=json.loads((phase/'binary-manifest.json').read_text())[choice]
E=DIAG/'release';E.mkdir(exist_ok=True);records=[]
beng=['src/share/text_analysis/ob_text_analyzer.cpp','src/share/text_analysis/ob_text_analyzer.h',
      'src/share/text_analysis/ob_token_stream.cpp','src/share/text_analysis/ob_token_stream.h',
      'src/storage/fts/ob_beng_ft_parser.cpp']
ref='02fb66c1d41e637a2f4aba7fe050e6028b6f23ef' if choice=='ik_only' else BASE
for p in beng:(REPO/p).write_bytes(git(ref,p))
for p,expected in variant['sources'].items():
    content=(REPO/p).read_bytes() if (REPO/p).exists() else git(BASE,p)
    assert hashlib.sha256(content).hexdigest()==expected,p
    dest=N/'source'/p
    if dest.read_bytes()!=content:dest.write_bytes(content)
run('build-release',[TOOLS/'bin/cmake','--build',N/'build','--target','seekdb','oceanbase','-j','3'])
binary=N/'bin/seekdb-release'
run('strip-release',[TOOLS/'bin/llvm-objcopy','--strip-debug',N/'build/src/observer/seekdb',binary])
assert hashlib.sha256(binary.read_bytes()).hexdigest()==variant['sha256'],'Rebuilt release differs from measured binary'
run('cpp-release',['python3',N/'source/unittest/storage/fts/run_fts_cpp.py',
                   '--build-dir',N/'build','--output',E/'cpp-release'])
(E/'selection.json').write_text(json.dumps(dict(choice=choice,measured_binary_sha256=variant['sha256'],
    rebuilt_binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),sources=variant['sources']),indent=2))

# Reuse the same process ownership checks and recorder, after benchmarks finish.
source=pathlib.Path(__file__).with_name('fts_ablation_measure.py').read_text()
sys.argv=[sys.argv[0],'--ik']
exec(compile(source[:source.index('for item in PLAN:')],'release_runtime_common.py','exec'))
E=DIAG/'release';records=[]
last=next(x for x in reversed(PLAN) if x['version']==choice)
MANIFEST[choice]['binary']=str(binary)
p=start(choice,'release',runtime(last['label']),False)
try:
    run('sql-release',['python3',SOURCE/'unittest/storage/fts/check_fts_sql.py','--mysql',CLIENT,
                       '--port','2901','--benchmark-results','--compare',
                       ROOT/'outputs/seekdb-fts-final/validation/fresh-reference.json','--output',E/'sql-release'])
    suite=SOURCE/'tools/deploy/mysql_test/test_suite/fts_index'
    for name in ['tokenize_function','parser_properties','parser_hot_path','simple_query']:
        test=suite/('t/'+name+'.test');expected=suite/('r/mysql/'+name+'.result')
        wrapper=E/(name+'.wrapper.test')
        wrapper.write_text('let $OBMYSQL_MS0=127.0.0.1;\nlet $OBMYSQL_PORT=2901;\nlet $OBMYSQL_PWD=;\nsource '+str(test)+';\n')
        input_test=wrapper if '$OBMYSQL' in test.read_text() else test
        before=expected.read_bytes()
        run('mysqltest-'+name,[CLIENT.parent/'mysqltest','--no-defaults','--protocol=tcp','--host=127.0.0.1',
            '--port=2901','--user=root','--database=oceanbase','--default-character-set=utf8mb4',
            '--test-file='+str(input_test),'--result-file='+str(expected),'--logdir='+str(E),'--tmpdir='+str(N)],cwd=suite)
        assert expected.read_bytes()==before
finally:stop(p)
print('RELEASE VERIFIED',choice,variant['sha256'],flush=True)
