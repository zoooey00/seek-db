"""Isolate BENG allocation changes from the retained IK changes."""
import pathlib
source=pathlib.Path(__file__).with_name('fts_final_build.py').read_text()
exec(compile(source[:source.index("PARENT=")],'fts_build_common.py','exec'))
E=ROOT/'outputs/seekdb-fts-diagnosis/ik-comparison'
E.mkdir(exist_ok=True)
PARENT='02fb66c1d41e637a2f4aba7fe050e6028b6f23ef'
paths=['src/share/text_analysis/ob_text_analyzer.cpp','src/share/text_analysis/ob_text_analyzer.h',
       'src/share/text_analysis/ob_token_stream.cpp','src/share/text_analysis/ob_token_stream.h',
       'src/storage/fts/ob_beng_ft_parser.cpp']
prior={p:(N/'source'/p).read_bytes() for p in paths}
manifest=json.loads((ROOT/'outputs/seekdb-fts-diagnosis/final-comparison/binary-manifest.json').read_text())
records=[]
try:
    for p in paths:(N/'source'/p).write_bytes(git(PARENT,p))
    run('build-ik-only',[TOOLS/'bin/cmake','--build',N/'build','--target','seekdb','oceanbase','-j','3'])
    binary=N/'bin/seekdb-ik-only'
    run('strip-ik-only',[TOOLS/'bin/llvm-objcopy','--strip-debug',N/'build/src/observer/seekdb',binary])
    run('cpp-ik-only',['python3',N/'source/unittest/storage/fts/run_fts_cpp.py',
                     '--build-dir',N/'build','--output',E/'cpp-ik-only'])
    manifest['ik_only']=dict(binary=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
        base_commit=BASE,restored_beng_files_from=PARENT,
        sources={p:hashlib.sha256((N/'source'/p).read_bytes()).hexdigest() for p in manifest['selected']['sources']})
    (E/'binary-manifest.json').write_text(json.dumps(manifest,indent=2))
finally:
    for p,b in prior.items():
        dest=N/'source'/p
        if dest.read_bytes()!=b:dest.write_bytes(b)
print('IK ONLY BUILT; SEVEN CPP GROUPS PASS',flush=True)
