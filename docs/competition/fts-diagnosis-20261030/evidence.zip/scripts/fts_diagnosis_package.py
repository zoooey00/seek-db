"""Package complete diagnostic evidence and a conservative final conclusion."""
import hashlib
import json
import pathlib
import shutil
import statistics
import subprocess
import zipfile

ROOT=pathlib.Path(__file__).resolve().parents[1]
REPO=ROOT/'work/submission'
E=ROOT/'outputs/seekdb-fts-diagnosis'
F=E/'final-comparison'
DOC=REPO/'docs/competition/fts-diagnosis-20261030'
DOC.mkdir(exist_ok=True)
def read(path):return json.loads(path.read_text(encoding='utf-8'))
ablation=read(E/'ablation-summary.json');final=read(F/'ablation-summary.json')
assert ablation['completed']==16 and final['completed']==8
state=read(F/'measure-state.json')
for name in ['sql-original','sql-selected']+['mysqltest-'+x for x in ['tokenize_function','parser_properties','parser_hot_path','simple_query']]:
    assert any(r['name']==name and r['exit_code']==0 for r in state),name
for p in [E/'build-state.json',F/'build-state.json']:
    assert all(r['exit_code']==0 for r in read(p))
for p in [E/'sql-frequency.log',E/'sql-stopword.log',E/'sql-candidate.log',F/'sql-original.log',F/'sql-selected.log']:
    content=p.read_text(encoding='utf-8')
    assert '"different_cases": []' in content,p
for path in ['src/storage/fts/ob_fts_stop_word.cpp','src/storage/fts/ob_fts_stop_word.h']:
    assert (REPO/path).read_bytes()==subprocess.check_output(['git','-C',str(REPO),'show','965b5d3:'+path])
baseline_blob=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD:tools/benchmark/fts_large_bench_baseline.json']).decode().strip()
assert baseline_blob==read(E/'upstream-ci-check.json')['baseline']['sha']

def pct(x):return f'{x*100:+.2f}%'
labels={'submitted':'上一提交的生产源码','frequency':'仅词频更新','stopword':'仅 ASCII 停用词索引','candidate':'两项同时启用'}
table=[]
for v,s in ablation['summaries'].items():
    table.append(f"| {labels[v]} | {pct(s['categories']['build'])} | {pct(s['categories']['tokenize'])} | {pct(s['categories']['query'])} | {pct(s['composite'])} |")
base=final['summaries']['original'];selected=final['summaries']['selected']
metrics=[]
for m,b in base['means'].items():
    if m=='select1_avg_ms':continue
    c=selected['means'][m]
    metrics.append(f'| {m} | {b:.6g} | {c:.6g} | {pct(1-c/b)} |')
fixed={}
for name,data,folder in [('ablation',ablation,E),('final',final,F)]:
    fixed[name]={r['label']:read(folder/(r['label']+'-score.log'))['score'] for r in data['runs']}
(E/'fixed-reference-scores.json').write_text(json.dumps(fixed,indent=2),encoding='utf-8')
allruns=ablation['runs']+final['runs']
minmem=min(r['telemetry']['min_mem_available_kib'] for r in allruns)/1024**2
maxmempressure=max(r['telemetry']['pressure_some_fraction']['memory'] for r in allruns)
maxiopressure=max(r['telemetry']['pressure_some_fraction']['io'] for r in allruns)
manifest=read(F/'binary-manifest.json')
text=f'''# 全文索引调优：拆分对照与最终选择

日期：2026-10-30。仓库：`zoooey00/seek-db`，分支：`perf/fts-ik-beng-20261029`。

## 最终处理

**功能验证通过，但当前实验仍未证明稳定的综合性能提升，不能认定性能目标已经完成。**

撤回 `0668450` 新增的单次词频更新和 ASCII 停用词索引，保留此前的 IK/BENG 优化、生命周期修复及新增语义回归测试。两项新增优化分别测试和一起测试都未显示可靠的整机收益，因此不继续把局部 CPU 测试的改善当作提交依据。

当前生产源码恢复为 `965b5d35ec36218bffd2ece8442b2bf8038d4c9a` 的状态，测试和说明材料进一步完善。此处“恢复”不撤销此前 12 个 FTS 生产文件的优化，也不改动已有 AI 相关代码。最终重新构建的可执行文件 SHA-256 与先前保留的 `965b5d3` 可执行文件完全相同。

这是一项依据有限测量作出的保守选择，不是对退化根因的确定性证明，也不保证平台提分。之前的八轮结果继续保留，本次新增 24 轮，全部记录均保留，没有选择性删除。

## 实验一：分离两处新增改动

旧版为 `965b5d3`，完整新增版为 `0668450`；另外两版只启用其中一项改动。四种版本按预先固定的平衡顺序运行 16 轮，每个版本占据每个出场位置一次，每个有序的版本转换在组内出现一次。每轮创建全新数据目录、启动后等待 20 秒，并完整重新导入和建索引。全部性能测试结束后才执行 SQL 回归。

三类各自先平均单项下降比例，再等权平均。下表以四轮耗时均值比较，正数表示改善；对照对象是旧提交，不是平台固定基线。

| 版本 | 构建 | 分词 | 查询 | 综合 |
|---|---:|---:|---:|---:|
{chr(10).join(table)}

两项同时启用版在四个组内相对旧版的综合提升率分别为 {', '.join(pct(x) for x in ablation['summaries']['candidate']['block_composites'])}。结果有波动，缺乏可靠正收益，因此撤回两处新增生产改动。原始数据见 `evidence/ablation-summary.json`，协议见 `evidence/protocol.json`。

## 实验二：最终保留优化与首次 FTS 修改前版本比较

初始对照为上传分支父提交 `02fb66c1d41e637a2f4aba7fe050e6028b6f23ef`，其 12 个 FTS 生产文件与原官方比较点一致，并保留该分支已有 AI 改动。最终版生产源码为 `965b5d3`。单独构建两版，按 原→终、终→原、终→原、原→终 四组完成八轮，每版四轮；不与实验一混算。

| 指标 | 初始版本均值 | 最终版本均值 | 耗时下降 |
|---|---:|---:|---:|
{chr(10).join(metrics)}

三类提升率：构建 {pct(selected['categories']['build'])}，分词 {pct(selected['categories']['tokenize'])}，查询 {pct(selected['categories']['query'])}；综合 **{pct(selected['composite'])}**。四组分别为 {', '.join(pct(x) for x in selected['block_composites'])}。这些是本机描述性结果，不是正式平台成绩，也不足以保证稳定收益或满分。

按公开固定基线计算，本次 24 轮参考分范围为 {min(x for d in fixed.values() for x in d.values()):.2f}～{max(x for d in fixed.values() for x in d.values()):.2f}/100。固定基线分数与上面相对本机初始版本的提升率比较对象不同；不能将固定基线参考分归因于代码改动，更不能替代平台成绩。

## 统一条件与已知限制

- 原始基准文件、生成数据、SQL、计时逻辑、评分脚本、固定基线和 CI 文件未修改。
- 参数为 `ROWS=20000 BATCH=500 ROUNDS=3000 QUERY_ROUNDS=200 SAMPLES=3 WARMUP=30 SKIP_LOAD=0`；每轮新报告，所有轮次有效且保留。
- WSL2 / Ubuntu 20.04，Clang 17，RelWithDebInfo；服务端 CPU 12,14，客户端 CPU 10；`cpu_count=2`、`memory_limit=2G`，专用端口 2901/2902。
- 每秒记录 CPU、内存、I/O 压力及数据库进程状态。测量窗口最少可用内存 {minmem:.2f} GiB，最高内存压力占比 {maxmempressure*100:.4f}%，最高 I/O 压力占比 {maxiopressure*100:.2f}%。记录没有显示明显内存不足，但这不能排除 CPU 频率、Windows 宿主机任务或其他调度影响。
- 另一个既有数据库实例保留运行，未擅自停止。CPU 亲和性不是独占 CPU；WSL 监控不能完整刻画 Windows 宿主机干扰。
- 未扣除 SELECT 1 耗时。旧实验严重退化未在相同幅度上重现，但不能据此断言旧结果无效或与代码无关。
- 增量构建保留的版本字符串及基准的 `git_head/git_dirty` 不能单独标识实验变体；以逐版本生产文件 SHA-256 和可执行文件 SHA-256 清单为准。最终二进制与已保存旧版逐字节一致。

## 最终正确性复验

重新构建 `seekdb` 和 `oceanbase`。最终七组 C++ 检查通过，包括 3,336,192 项字符分类对照、生命周期/分配失败，以及 121,140 项停用词语义对照。三种新增改动版本分别完成 936 项完整 SQL 对照；最终版和首次 FTS 修改前版也各完成 936 项对照，全部一致。

最终四项 mysqltest：`tokenize_function`、`parser_properties`、`parser_hot_path`、`simple_query` 全部通过，预期文件未修改。未声称整个官方套件通过。全部本次专用测试实例已停止。

初始可执行文件 SHA-256：`{manifest['original']['sha256']}`。

最终可执行文件 SHA-256：`{manifest['selected']['sha256']}`。

## 平台仍待确认

2026-10-30 通过 GitHub 只读接口重新核对 `oceanbase/seekdb` 的 `2026-competition` 分支：公开基线 Git blob 为 `{baseline_blob}`，与提交仓库一致；`.github/workflows/vldb.yml` 返回 404。可读取的 `seekdb.yml` 是另一个 CI，使用 OceanBase 专用 runner 且限制仓库所有者为 oceanbase，不能直接当作个人仓库的比赛评分入口。

因此未自行新增或篡改评分工作流。此前平台返回的九项耗时按公开文件复算与平台返回分数不一致，实际平台评分输入仍需平台确认。尚未重新提交比赛平台。可直接使用本目录 `PLATFORM_CHECK.md` 的核对材料；它是待发送文本，没有代发给任何人。

## 证据与复现

`evidence.zip` 包含两次实验的全部原始报告、评分、负载采样、构建记录、SQL 结果、C++/mysqltest 日志、源码及二进制校验、诊断脚本快照。`evidence/` 提供可直接浏览的汇总和全部原始基准报告。脚本快照记录本次本机实验，使用本机原工作区路径，并非通用安装器；标准复验方法仍见 `unittest/storage/fts/README.md` 和未修改的官方基准脚本。
'''
(E/'最终排查报告.md').write_text(text,encoding='utf-8')
(DOC/'REPORT.md').write_text(text,encoding='utf-8')
platform='''# 平台评分核对与重新提测材料

仓库：https://github.com/zoooey00/seek-db

分支：`perf/fts-ik-beng-20261029`。重新提测时请确认平台实际拉取的提交等于此分支最新提交；旧的 `0668450` 已被后续撤回两项新增优化的提交替代。GitHub 上传不是平台提测。

以下文本供参赛者发给赛题负责人；未自动发送：

> 赛题四全文索引调优，提测页 questionId=600080。此前提交 `965b5d35ec36218bffd2ece8442b2bf8038d4c9a` 的评分明细给出综合提升率 −2.4996646108%、原始分 0。将同一组九项耗时代入公开基线和评分脚本，参数校验通过，复算综合提升率 +86.0952177073%、原始分 100。这里不是要求按本地结果改分，而是希望确认实际评分输入。请提供：实际拉取的提交 SHA；九项基线耗时及基线版本/哈希；评分脚本版本和执行命令；三类提升率明细；正式评测入口是否由平台外部提供。公开 2026-competition 分支的 `.github/workflows/vldb.yml` 当前返回 404。

旧平台明细来自此前提供的数据，不是本次重新提测结果。旧明细及公开文件复算见附带 `platform-provided-metrics.json`、`published-baseline-recalculation.json`。不能据此声称正式成绩应为满分。

重新提测后，应核对：提交 SHA 正确；规定七项参数一致；九项计分指标齐全；功能测试状态；三类分别平均后等权计算。评分函数只在最终综合提升率上截断，不能将单项退化归零。
'''
(E/'平台评分核对说明.md').write_text(platform,encoding='utf-8')
(DOC/'PLATFORM_CHECK.md').write_text(platform,encoding='utf-8')
for name in ['platform-provided-metrics.json','published-baseline-recalculation.json']:
    shutil.copyfile(ROOT/'outputs/seekdb-fts-v2'/name,E/name)
    shutil.copyfile(E/name,DOC/name)

# Keep historical results verbatim and add only a current-status pointer.
for name in ['fts-hot-path-20261029','fts-hot-path-20261030']:
    p=REPO/'docs/competition'/name/'REPORT.md'
    original=p.read_text(encoding='utf-8')
    note='> 最新状态：两项新增优化已撤回，完整拆分实验和最终版本验证见 [排查报告](../fts-diagnosis-20261030/REPORT.md)。本文为历史记录。\n\n'
    if note not in original:
        first,rest=original.split('\n',1)
        p.write_text(first+'\n\n'+note+rest.lstrip('\n'),encoding='utf-8')

allowed={'.json','.jsonl','.txt','.log','.cpp','.test','.md'}
files=[p for p in E.rglob('*') if p.is_file() and p.suffix in allowed and p.name not in ['publication.json','evidence-manifest.json']]
with zipfile.ZipFile(E/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):z.write(p,p.relative_to(E).as_posix())
    for p in sorted((ROOT/'work').glob('fts_*.py')):z.write(p,'scripts/'+p.name)
shutil.copyfile(E/'evidence.zip',DOC/'evidence.zip')
for folder,relative in [(E,pathlib.Path()),(F,pathlib.Path('final-comparison'))]:
    dest=DOC/'evidence'/relative;dest.mkdir(parents=True,exist_ok=True)
    names=['ablation-summary.json','protocol.json','binary-manifest.json','build-state.json','measure-state.json','benchmark-integrity.json']
    if folder==E:names+=['upstream-ci-check.json','fixed-reference-scores.json']
    for name in names:shutil.copyfile(folder/name,dest/name)
    for pattern in ['b*-p*-*.txt','b*-p*-*-score.log','sql-*.log']:
        for p in folder.glob(pattern):shutil.copyfile(p,dest/p.name)
(E/'evidence-manifest.json').write_text(json.dumps(dict(
    archive_sha256=hashlib.sha256((E/'evidence.zip').read_bytes()).hexdigest(),
    archive_size=(E/'evidence.zip').stat().st_size,
    production_sources_equal_commit='965b5d35ec36218bffd2ece8442b2bf8038d4c9a',
    total_new_benchmark_rounds=24,platform_resubmitted=False),indent=2),encoding='utf-8')
shutil.copyfile(E/'evidence-manifest.json',DOC/'evidence-manifest.json')
for p in list(DOC.rglob('*'))+[REPO/'docs/competition'/name/'REPORT.md' for name in ['fts-hot-path-20261029','fts-hot-path-20261030']]:
    if p.is_file() and p.suffix in ['.md','.json','.txt','.log']:
        p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
print('PACKAGED',DOC)
print('Final improvement',selected['composite'],'blocks',selected['block_composites'])
